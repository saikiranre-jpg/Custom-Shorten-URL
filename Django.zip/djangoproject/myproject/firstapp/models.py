from django.db import models

# Create your models here.
class longtoshort(models.Model):
    long_url=models.URLField(max_length=200)
    shorturl=models.CharField(max_length=200,unique=True)
    date=models.DateField(auto_now_add=True)
    clicks=models.IntegerField(default=0)
