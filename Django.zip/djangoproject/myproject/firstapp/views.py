from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import longtoshort

def hello_world(request):
    return HttpResponse("Hello World")

def home_page(request):
    context={'submitted':False,'error':False}
    if request.method == 'POST':
        long_url=request.POST['longurl']
        customname=request.POST['custom_name']
        context['shorturl']=request.build_absolute_uri()+customname
        context['longurl']=long_url
        try:
            obj=longtoshort(long_url=long_url,shorturl=customname)
            obj.save()
            context['submitted']=True
        except:
            context['error']=True
        context['date']=obj.date
        context['clicks']=obj.clicks
    else:
        print(request.GET)
    return render(request,'index.html',context)

def analytics(request):
    row=longtoshort.objects.all()
    context={
        "rows":row
    }
    return render(request,'analytics.html',context)

def redirect_url(request,shorturl):
    row=longtoshort.objects.filter(shorturl=shorturl)

    if(len(row)==0):
        return HttpResponse("No such short url exists")
    
    obj=row[0]
    obj.clicks+=1
    obj.save()
    return redirect(obj.long_url)